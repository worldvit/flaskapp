# flaskapp
# 최상위 폴더 및 하위 데이터/설정 폴더 생성
mkdir -p flaskapp/data/certbot/{conf,www} \
         flaskapp/data/mysql \
         flaskapp/data/mysql-init \
         flaskapp/nginx \
         flaskapp/src/{static,templates}
